"use strict";
/**
 * レスポンスユーティリティ
 *
 * このファイルはAPIレスポンスを生成するためのユーティリティ関数を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSuccessResponse = createSuccessResponse;
exports.createErrorResponse = createErrorResponse;
const errors_1 = require("./errors");
/**
 * 成功レスポンスを生成
 *
 * @param data レスポンスデータ
 * @param statusCode HTTPステータスコード（デフォルト: 200）
 * @returns APIGatewayProxyResult
 */
function createSuccessResponse(data, statusCode = 200) {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    };
}
/**
 * エラーレスポンスを生成
 *
 * @param error エラーオブジェクト
 * @returns APIGatewayProxyResult
 */
function createErrorResponse(error) {
    console.error('エラー:', error);
    if (error instanceof errors_1.AppError) {
        return {
            statusCode: error.statusCode,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(error.toResponse())
        };
    }
    // 未知のエラーの場合は500エラーを返す
    return {
        statusCode: 500,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'サーバー内部エラーが発生しました'
            }
        })
    };
}
//# sourceMappingURL=response.js.map