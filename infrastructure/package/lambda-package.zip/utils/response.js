"use strict";
/**
 * レスポンスユーティリティ
 *
 * このファイルはAPIレスポンスを生成するためのユーティリティ関数を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSuccessResponse = createSuccessResponse;
exports.createErrorResponse = createErrorResponse;
const errors_1 = require("./errors");
/**
 * 成功レスポンスを生成
 *
 * @param data レスポンスデータ
 * @param statusCode HTTPステータスコード（デフォルト: 200）
 * @returns APIGatewayProxyResult
 */
function createSuccessResponse(data, statusCode = 200) {
    // レスポンスデータをログに出力
    console.log('APIレスポンス:', {
        statusCode,
        data
    });
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    };
}
/**
 * エラーレスポンスを生成
 *
 * @param error エラーオブジェクト
 * @returns APIGatewayProxyResult
 */
function createErrorResponse(error) {
    console.error('エラー:', error);
    let response;
    if (error instanceof errors_1.AppError) {
        const errorResponse = error.toResponse();
        // エラーレスポンスをログに出力
        console.log('APIエラーレスポンス:', {
            statusCode: error.statusCode,
            error: errorResponse
        });
        response = {
            statusCode: error.statusCode,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(errorResponse)
        };
    }
    else {
        // 未知のエラーの場合は500エラーを返す
        const errorResponse = {
            error: {
                code: 'INTERNAL_ERROR',
                message: 'サーバー内部エラーが発生しました'
            }
        };
        // エラーレスポンスをログに出力
        console.log('APIエラーレスポンス:', {
            statusCode: 500,
            error: errorResponse
        });
        response = {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(errorResponse)
        };
    }
    return response;
}
//# sourceMappingURL=response.js.map