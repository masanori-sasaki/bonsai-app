"use strict";
/**
 * 認証ユーティリティ
 *
 * このファイルは認証関連のユーティリティ関数を提供します。
 * AWS Lambda関数とExpress.jsの両方で使用できます。
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateToken = generateToken;
exports.verifyToken = verifyToken;
exports.authMiddleware = authMiddleware;
exports.getUserIdFromRequest = getUserIdFromRequest;
exports.getTokenFromRequest = getTokenFromRequest;
exports.getUserEmailFromRequest = getUserEmailFromRequest;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const errors_1 = require("./errors");
// JWT署名用のシークレットキー（開発環境用）
// 本番環境では環境変数から取得するか、AWS Secrets Managerなどを使用
const JWT_SECRET = process.env.JWT_SECRET || 'bonsai-app-development-secret-key';
// トークンの有効期限（1日）
const TOKEN_EXPIRATION = '1d';
/**
 * JWTトークンを生成
 *
 * @param payload トークンに含めるデータ
 * @returns 生成されたトークン
 */
function generateToken(payload) {
    return jsonwebtoken_1.default.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRATION });
}
/**
 * JWTトークンを検証
 *
 * @param token 検証するトークン
 * @returns デコードされたペイロード
 * @throws Error トークンが無効な場合
 */
function verifyToken(token) {
    try {
        return jsonwebtoken_1.default.verify(token, JWT_SECRET);
    }
    catch (error) {
        throw new errors_1.UnauthorizedError('無効なトークンです');
    }
}
/**
 * Express.js用の認証ミドルウェア
 *
 * @param req リクエスト
 * @param res レスポンス
 * @param next 次のミドルウェア
 */
function authMiddleware(req, res, next) {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new errors_1.UnauthorizedError('認証ヘッダーがありません');
        }
        const token = authHeader.split(' ')[1];
        const decoded = verifyToken(token);
        // リクエストオブジェクトにユーザー情報を追加
        req.user = decoded;
        next();
    }
    catch (error) {
        res.status(401).json({
            message: error instanceof Error ? error.message : '認証に失敗しました'
        });
    }
}
/**
 * リクエストからユーザーIDを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns ユーザーID
 * @throws UnauthorizedError 認証情報が不足している場合
 */
function getUserIdFromRequest(event) {
    var _a;
    // 開発環境の場合は固定のユーザーIDを返す
    if (!event.requestContext || !event.requestContext.authorizer) {
        console.log('開発環境用の固定ユーザーIDを使用します');
        return 'dev-user-123';
    }
    // 認証情報はAPI Gateway/Lambda Function URLの統合によって
    // requestContext.authorizer.claimsに格納される
    const claims = (_a = event.requestContext.authorizer) === null || _a === void 0 ? void 0 : _a.claims;
    if (!claims || !claims.sub) {
        throw new errors_1.UnauthorizedError('有効な認証情報がありません');
    }
    return claims.sub;
}
/**
 * リクエストからIDトークンを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns IDトークン
 * @throws UnauthorizedError 認証情報が不足している場合
 */
function getTokenFromRequest(event) {
    const authHeader = event.headers.Authorization || event.headers.authorization;
    if (!authHeader) {
        throw new errors_1.UnauthorizedError('認証ヘッダーがありません');
    }
    const match = authHeader.match(/^Bearer\s+(.*)$/);
    if (!match) {
        throw new errors_1.UnauthorizedError('無効な認証ヘッダー形式です');
    }
    return match[1];
}
/**
 * リクエストからユーザーのメールアドレスを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns メールアドレス
 * @throws UnauthorizedError 認証情報が不足している場合
 */
function getUserEmailFromRequest(event) {
    var _a;
    // 開発環境の場合は固定のメールアドレスを返す
    if (!event.requestContext || !event.requestContext.authorizer) {
        console.log('開発環境用の固定メールアドレスを使用します');
        return 'dev-user@example.com';
    }
    const claims = (_a = event.requestContext.authorizer) === null || _a === void 0 ? void 0 : _a.claims;
    if (!claims || !claims.email) {
        throw new errors_1.UnauthorizedError('有効な認証情報がありません');
    }
    return claims.email;
}
//# sourceMappingURL=auth.js.map