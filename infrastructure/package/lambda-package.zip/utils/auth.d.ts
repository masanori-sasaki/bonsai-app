/**
 * 認証ユーティリティ
 *
 * このファイルは認証関連のユーティリティ関数を提供します。
 * AWS Lambda関数とExpress.jsの両方で使用できます。
 */
import { APIGatewayProxyEvent } from 'aws-lambda';
import { Request, Response, NextFunction } from 'express';
/**
 * JWTトークンを生成
 *
 * @param payload トークンに含めるデータ
 * @returns 生成されたトークン
 */
export declare function generateToken(payload: any): string;
/**
 * JWTトークンを検証
 *
 * @param token 検証するトークン
 * @returns デコードされたペイロード
 * @throws Error トークンが無効な場合
 */
export declare function verifyToken(token: string): any;
/**
 * Express.js用の認証ミドルウェア
 *
 * @param req リクエスト
 * @param res レスポンス
 * @param next 次のミドルウェア
 */
export declare function authMiddleware(req: Request, res: Response, next: NextFunction): void;
/**
 * リクエストからユーザーIDを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns ユーザーID
 * @throws UnauthorizedError 認証情報が不足している場合
 */
export declare function getUserIdFromRequest(event: APIGatewayProxyEvent): string;
/**
 * リクエストからIDトークンを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns IDトークン
 * @throws UnauthorizedError 認証情報が不足している場合
 */
export declare function getTokenFromRequest(event: APIGatewayProxyEvent): string;
/**
 * リクエストからユーザーのメールアドレスを取得
 *
 * @param event APIGatewayProxyEvent
 * @returns メールアドレス
 * @throws UnauthorizedError 認証情報が不足している場合
 */
export declare function getUserEmailFromRequest(event: APIGatewayProxyEvent): string;
