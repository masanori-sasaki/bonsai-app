/**
 * レスポンスユーティリティ
 *
 * このファイルはAPIレスポンスを生成するためのユーティリティ関数を提供します。
 */
import { APIGatewayProxyResult } from 'aws-lambda';
/**
 * 成功レスポンスを生成
 *
 * @param data レスポンスデータ
 * @param statusCode HTTPステータスコード（デフォルト: 200）
 * @returns APIGatewayProxyResult
 */
export declare function createSuccessResponse(data: any, statusCode?: number): APIGatewayProxyResult;
/**
 * エラーレスポンスを生成
 *
 * @param error エラーオブジェクト
 * @returns APIGatewayProxyResult
 */
export declare function createErrorResponse(error: Error): APIGatewayProxyResult;
