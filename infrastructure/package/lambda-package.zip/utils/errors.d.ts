/**
 * エラーユーティリティ
 *
 * このファイルはアプリケーション全体で使用するエラー関連のユーティリティを提供します。
 */
/**
 * エラーコード
 */
export declare enum ErrorCode {
    INVALID_REQUEST = "INVALID_REQUEST",
    UNAUTHORIZED = "UNAUTHORIZED",
    FORBIDDEN = "FORBIDDEN",
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND",
    VALIDATION_ERROR = "VALIDATION_ERROR",
    CONFLICT = "CONFLICT",
    INTERNAL_ERROR = "INTERNAL_ERROR"
}
/**
 * APIエラーレスポンス
 */
export interface ApiErrorResponse {
    error: {
        code: ErrorCode;
        message: string;
        details?: Record<string, any>;
    };
}
/**
 * アプリケーションエラークラス
 */
export declare class AppError extends Error {
    readonly code: ErrorCode;
    readonly statusCode: number;
    readonly details?: Record<string, any>;
    constructor(code: ErrorCode, message: string, statusCode: number, details?: Record<string, any>);
    /**
     * APIエラーレスポンスに変換
     */
    toResponse(): ApiErrorResponse;
}
/**
 * 無効なリクエストエラー
 */
export declare class InvalidRequestError extends AppError {
    constructor(message: string, details?: Record<string, any>);
}
/**
 * 認証エラー
 */
export declare class UnauthorizedError extends AppError {
    constructor(message?: string);
}
/**
 * 権限エラー
 */
export declare class ForbiddenError extends AppError {
    constructor(message?: string);
}
/**
 * リソース未検出エラー
 */
export declare class ResourceNotFoundError extends AppError {
    constructor(resourceType: string, resourceId: string);
}
/**
 * バリデーションエラー
 */
export declare class ValidationError extends AppError {
    constructor(message: string, details?: Record<string, any>);
}
/**
 * 競合エラー
 */
export declare class ConflictError extends AppError {
    constructor(message: string, details?: Record<string, any>);
}
/**
 * 内部エラー
 */
export declare class InternalError extends AppError {
    constructor(message?: string);
}
