"use strict";
/**
 * エラーユーティリティ
 *
 * このファイルはアプリケーション全体で使用するエラー関連のユーティリティを提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalError = exports.ConflictError = exports.ValidationError = exports.ResourceNotFoundError = exports.ForbiddenError = exports.UnauthorizedError = exports.InvalidRequestError = exports.AppError = exports.ErrorCode = void 0;
/**
 * エラーコード
 */
var ErrorCode;
(function (ErrorCode) {
    ErrorCode["INVALID_REQUEST"] = "INVALID_REQUEST";
    ErrorCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCode["FORBIDDEN"] = "FORBIDDEN";
    ErrorCode["RESOURCE_NOT_FOUND"] = "RESOURCE_NOT_FOUND";
    ErrorCode["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCode["CONFLICT"] = "CONFLICT";
    ErrorCode["INTERNAL_ERROR"] = "INTERNAL_ERROR";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
/**
 * アプリケーションエラークラス
 */
class AppError extends Error {
    constructor(code, message, statusCode, details) {
        super(message);
        this.name = 'AppError';
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
    }
    /**
     * APIエラーレスポンスに変換
     */
    toResponse() {
        return {
            error: {
                code: this.code,
                message: this.message,
                details: this.details
            }
        };
    }
}
exports.AppError = AppError;
/**
 * 無効なリクエストエラー
 */
class InvalidRequestError extends AppError {
    constructor(message, details) {
        super(ErrorCode.INVALID_REQUEST, message, 400, details);
        this.name = 'InvalidRequestError';
    }
}
exports.InvalidRequestError = InvalidRequestError;
/**
 * 認証エラー
 */
class UnauthorizedError extends AppError {
    constructor(message = '認証が必要です') {
        super(ErrorCode.UNAUTHORIZED, message, 401);
        this.name = 'UnauthorizedError';
    }
}
exports.UnauthorizedError = UnauthorizedError;
/**
 * 権限エラー
 */
class ForbiddenError extends AppError {
    constructor(message = '権限がありません') {
        super(ErrorCode.FORBIDDEN, message, 403);
        this.name = 'ForbiddenError';
    }
}
exports.ForbiddenError = ForbiddenError;
/**
 * リソース未検出エラー
 */
class ResourceNotFoundError extends AppError {
    constructor(resourceType, resourceId) {
        super(ErrorCode.RESOURCE_NOT_FOUND, `指定された${resourceType}が見つかりませんでした`, 404, { resourceType, resourceId });
        this.name = 'ResourceNotFoundError';
    }
}
exports.ResourceNotFoundError = ResourceNotFoundError;
/**
 * バリデーションエラー
 */
class ValidationError extends AppError {
    constructor(message, details) {
        super(ErrorCode.VALIDATION_ERROR, message, 400, details);
        this.name = 'ValidationError';
    }
}
exports.ValidationError = ValidationError;
/**
 * 競合エラー
 */
class ConflictError extends AppError {
    constructor(message, details) {
        super(ErrorCode.CONFLICT, message, 409, details);
        this.name = 'ConflictError';
    }
}
exports.ConflictError = ConflictError;
/**
 * 内部エラー
 */
class InternalError extends AppError {
    constructor(message = 'サーバー内部エラーが発生しました') {
        super(ErrorCode.INTERNAL_ERROR, message, 500);
        this.name = 'InternalError';
    }
}
exports.InternalError = InternalError;
//# sourceMappingURL=errors.js.map