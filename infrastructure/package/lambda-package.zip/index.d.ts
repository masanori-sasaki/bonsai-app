/**
 * Bonsai App Server
 *
 * このファイルはアプリケーションのエントリーポイントです。
 * AWS Lambda関数のハンドラーとして機能します。
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Lambda関数のハンドラー
 * API Gatewayからのリクエストを処理します
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
