/**
 * 作業記録モデル
 *
 * このファイルは作業記録データのモデル定義を提供します。
 */
/**
 * 作業タイプ
 */
export type WorkType = 'pruning' | 'repotting' | 'watering' | 'fertilizing' | 'other';
/**
 * 作業記録インターフェース
 */
export interface WorkRecord {
    id: string;
    bonsaiId: string;
    workType: WorkType;
    date: string;
    description: string;
    imageUrls: string[];
    createdAt: string;
    updatedAt: string;
}
/**
 * 作業記録作成リクエスト
 */
export interface CreateWorkRecordRequest {
    bonsaiId: string;
    workType: WorkType;
    date: string;
    description: string;
    imageUrls?: string[];
}
/**
 * 作業記録更新リクエスト
 */
export interface UpdateWorkRecordRequest {
    workType?: WorkType;
    date?: string;
    description?: string;
    imageUrls?: string[];
}
/**
 * 作業記録一覧レスポンス
 */
export interface WorkRecordListResponse {
    items: WorkRecord[];
    nextToken?: string;
}
