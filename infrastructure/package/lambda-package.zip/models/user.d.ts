/**
 * ユーザーモデル
 *
 * このファイルはユーザーデータのモデル定義を提供します。
 */
/**
 * ユーザーインターフェース
 */
export interface User {
    id: string;
    email: string;
    name: string;
    createdAt: string;
    updatedAt: string;
}
/**
 * ユーザープロファイル更新リクエスト
 */
export interface UpdateUserProfileRequest {
    name?: string;
}
