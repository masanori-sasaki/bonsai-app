"use strict";
/**
 * 作業記録モデル
 *
 * このファイルは作業記録データのモデル定義を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=workRecord.js.map