"use strict";
/**
 * 盆栽モデル
 *
 * このファイルは盆栽データのモデル定義を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=bonsai.js.map