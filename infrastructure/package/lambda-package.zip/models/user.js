"use strict";
/**
 * ユーザーモデル
 *
 * このファイルはユーザーデータのモデル定義を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=user.js.map