"use strict";
/**
 * 作業予定モデル
 *
 * このファイルは作業予定データのモデル定義を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=workSchedule.js.map