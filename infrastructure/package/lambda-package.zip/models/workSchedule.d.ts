/**
 * 作業予定モデル
 *
 * このファイルは作業予定データのモデル定義を提供します。
 */
import { WorkType } from './workRecord';
/**
 * 作業予定インターフェース
 */
export interface WorkSchedule {
    id: string;
    bonsaiId: string;
    workType: WorkType;
    scheduledDate: string;
    description: string;
    completed: boolean;
    createdAt: string;
    updatedAt: string;
}
/**
 * 作業予定作成リクエスト
 */
export interface CreateWorkScheduleRequest {
    bonsaiId: string;
    workType: WorkType;
    scheduledDate: string;
    description: string;
}
/**
 * 作業予定更新リクエスト
 */
export interface UpdateWorkScheduleRequest {
    workType?: WorkType;
    scheduledDate?: string;
    description?: string;
    completed?: boolean;
}
/**
 * 作業予定一覧レスポンス
 */
export interface WorkScheduleListResponse {
    items: WorkSchedule[];
    nextToken?: string;
}
