/**
 * 作業予定サービス
 *
 * このファイルは作業予定データの操作に関するビジネスロジックを提供します。
 */
import { WorkSchedule, WorkScheduleListResponse, CreateWorkScheduleRequest, UpdateWorkScheduleRequest } from '../models/workSchedule';
/**
 * 作業予定一覧を取得
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @param completed 完了状態でフィルタリング（オプション）
 * @param limit 取得件数（オプション）
 * @param nextToken ページネーショントークン（オプション）
 * @returns 作業予定一覧レスポンス
 */
export declare function listWorkSchedules(userId: string, bonsaiId: string, completed?: boolean, limit?: number, nextToken?: string): Promise<WorkScheduleListResponse>;
/**
 * 作業予定詳細を取得
 *
 * @param scheduleId 作業予定ID
 * @returns 作業予定詳細
 */
export declare function getWorkSchedule(scheduleId: string): Promise<WorkSchedule>;
/**
 * 作業予定を作成
 *
 * @param userId ユーザーID
 * @param data 作業予定作成リクエスト
 * @returns 作成された作業予定
 */
export declare function createWorkSchedule(userId: string, data: CreateWorkScheduleRequest): Promise<WorkSchedule>;
/**
 * 作業予定を更新
 *
 * @param scheduleId 作業予定ID
 * @param data 作業予定更新リクエスト
 * @returns 更新された作業予定
 */
export declare function updateWorkSchedule(scheduleId: string, data: UpdateWorkScheduleRequest): Promise<WorkSchedule>;
/**
 * 作業予定を削除
 *
 * @param scheduleId 作業予定ID
 */
export declare function deleteWorkSchedule(scheduleId: string): Promise<void>;
