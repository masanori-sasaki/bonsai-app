/**
 * 盆栽サービス
 *
 * このファイルは盆栽データの操作に関するビジネスロジックを提供します。
 */
import { Bonsai, BonsaiListResponse, CreateBonsaiRequest, UpdateBonsaiRequest } from '../models/bonsai';
/**
 * 盆栽一覧を取得
 *
 * @param userId ユーザーID
 * @param limit 取得件数（オプション）
 * @param nextToken ページネーショントークン（オプション）
 * @returns 盆栽一覧レスポンス
 */
export declare function listBonsai(userId: string, limit?: number, nextToken?: string): Promise<BonsaiListResponse>;
/**
 * 盆栽詳細を取得
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @returns 盆栽詳細
 */
export declare function getBonsai(userId: string, bonsaiId: string): Promise<Bonsai>;
/**
 * 盆栽を作成
 *
 * @param userId ユーザーID
 * @param data 盆栽作成リクエスト
 * @returns 作成された盆栽
 */
export declare function createBonsai(userId: string, data: CreateBonsaiRequest): Promise<Bonsai>;
/**
 * 盆栽を更新
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @param data 盆栽更新リクエスト
 * @returns 更新された盆栽
 */
export declare function updateBonsai(userId: string, bonsaiId: string, data: UpdateBonsaiRequest): Promise<Bonsai>;
/**
 * 盆栽を削除
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 */
export declare function deleteBonsai(userId: string, bonsaiId: string): Promise<void>;
