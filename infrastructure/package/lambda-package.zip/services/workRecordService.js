"use strict";
/**
 * 作業記録サービス
 *
 * このファイルは作業記録データの操作に関するビジネスロジックを提供します。
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.listWorkRecords = listWorkRecords;
exports.getWorkRecord = getWorkRecord;
exports.createWorkRecord = createWorkRecord;
exports.updateWorkRecord = updateWorkRecord;
exports.deleteWorkRecord = deleteWorkRecord;
const errors_1 = require("../utils/errors");
const bonsaiService = __importStar(require("./bonsaiService"));
const dataStore_1 = require("../data/dataStore");
// 作業記録データストアの作成
const workRecordStore = (0, dataStore_1.createDataStore)('workRecord');
/**
 * 作業記録一覧を取得
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @param workType 作業タイプでフィルタリング（オプション）
 * @param limit 取得件数（オプション）
 * @param nextToken ページネーショントークン（オプション）
 * @returns 作業記録一覧レスポンス
 */
async function listWorkRecords(userId, bonsaiId, workType, limit, nextToken) {
    // 盆栽の存在確認
    await bonsaiService.getBonsai(userId, bonsaiId);
    // すべての作業記録を取得
    const allRecords = await workRecordStore.getAll();
    // 盆栽IDに紐づく作業記録をフィルタリング
    let records = allRecords.filter(record => record.bonsaiId === bonsaiId);
    // 作業タイプでフィルタリング
    if (workType) {
        records = records.filter(record => record.workType === workType);
    }
    // ページネーション処理
    const pageSize = limit || 20;
    let startIndex = 0;
    if (nextToken) {
        try {
            // nextTokenから開始インデックスを取得
            const decodedToken = Buffer.from(nextToken, 'base64').toString('utf-8');
            const tokenData = JSON.parse(decodedToken);
            startIndex = tokenData.lastIndex || 0;
        }
        catch (error) {
            console.error('ページネーショントークンのデコードエラー:', error);
            startIndex = 0;
        }
    }
    // 指定された件数分のデータを取得
    const endIndex = Math.min(startIndex + pageSize, records.length);
    const items = records.slice(startIndex, endIndex);
    // 次ページがある場合はnextTokenを生成
    let responseNextToken;
    if (endIndex < records.length) {
        const tokenData = { lastIndex: endIndex };
        responseNextToken = Buffer.from(JSON.stringify(tokenData)).toString('base64');
    }
    return {
        items,
        nextToken: responseNextToken
    };
}
/**
 * 作業記録詳細を取得
 *
 * @param recordId 作業記録ID
 * @returns 作業記録詳細
 */
async function getWorkRecord(recordId) {
    // 作業記録IDに一致するデータを検索
    const record = await workRecordStore.getById(recordId);
    if (!record) {
        throw new errors_1.ResourceNotFoundError('作業記録', recordId);
    }
    return record;
}
/**
 * 作業記録を作成
 *
 * @param userId ユーザーID
 * @param data 作業記録作成リクエスト
 * @returns 作成された作業記録
 */
async function createWorkRecord(userId, data) {
    // 盆栽の存在確認
    await bonsaiService.getBonsai(userId, data.bonsaiId);
    // 新しい作業記録データを作成
    const newRecord = await workRecordStore.create({
        bonsaiId: data.bonsaiId,
        workType: data.workType,
        date: data.date,
        description: data.description,
        imageUrls: data.imageUrls || []
    });
    return newRecord;
}
/**
 * 作業記録を更新
 *
 * @param recordId 作業記録ID
 * @param data 作業記録更新リクエスト
 * @returns 更新された作業記録
 */
async function updateWorkRecord(recordId, data) {
    // 作業記録が存在するか確認
    await getWorkRecord(recordId);
    // 更新データを作成
    const updatedRecord = await workRecordStore.update(recordId, {
        workType: data.workType,
        date: data.date,
        description: data.description,
        imageUrls: data.imageUrls
    });
    return updatedRecord;
}
/**
 * 作業記録を削除
 *
 * @param recordId 作業記録ID
 */
async function deleteWorkRecord(recordId) {
    // 作業記録が存在するか確認
    await getWorkRecord(recordId);
    // データストアから削除
    await workRecordStore.delete(recordId);
}
//# sourceMappingURL=workRecordService.js.map