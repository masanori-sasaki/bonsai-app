"use strict";
/**
 * 作業予定サービス
 *
 * このファイルは作業予定データの操作に関するビジネスロジックを提供します。
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.listWorkSchedules = listWorkSchedules;
exports.getWorkSchedule = getWorkSchedule;
exports.createWorkSchedule = createWorkSchedule;
exports.updateWorkSchedule = updateWorkSchedule;
exports.deleteWorkSchedule = deleteWorkSchedule;
const errors_1 = require("../utils/errors");
const bonsaiService = __importStar(require("./bonsaiService"));
const dataStore_1 = require("../data/dataStore");
// 作業予定データストアの作成
const workScheduleStore = (0, dataStore_1.createDataStore)('workSchedule');
/**
 * 作業予定一覧を取得
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @param completed 完了状態でフィルタリング（オプション）
 * @param limit 取得件数（オプション）
 * @param nextToken ページネーショントークン（オプション）
 * @returns 作業予定一覧レスポンス
 */
async function listWorkSchedules(userId, bonsaiId, completed, limit, nextToken) {
    // 盆栽の存在確認
    await bonsaiService.getBonsai(userId, bonsaiId);
    // すべての作業予定を取得
    const allSchedules = await workScheduleStore.getAll();
    // 盆栽IDに紐づく作業予定をフィルタリング
    let schedules = allSchedules.filter(schedule => schedule.bonsaiId === bonsaiId);
    // 完了状態でフィルタリング
    if (completed !== undefined) {
        schedules = schedules.filter(schedule => schedule.completed === completed);
    }
    // ページネーション処理
    const pageSize = limit || 20;
    let startIndex = 0;
    if (nextToken) {
        try {
            // nextTokenから開始インデックスを取得
            const decodedToken = Buffer.from(nextToken, 'base64').toString('utf-8');
            const tokenData = JSON.parse(decodedToken);
            startIndex = tokenData.lastIndex || 0;
        }
        catch (error) {
            console.error('ページネーショントークンのデコードエラー:', error);
            startIndex = 0;
        }
    }
    // 指定された件数分のデータを取得
    const endIndex = Math.min(startIndex + pageSize, schedules.length);
    const items = schedules.slice(startIndex, endIndex);
    // 次ページがある場合はnextTokenを生成
    let responseNextToken;
    if (endIndex < schedules.length) {
        const tokenData = { lastIndex: endIndex };
        responseNextToken = Buffer.from(JSON.stringify(tokenData)).toString('base64');
    }
    return {
        items,
        nextToken: responseNextToken
    };
}
/**
 * 作業予定詳細を取得
 *
 * @param scheduleId 作業予定ID
 * @returns 作業予定詳細
 */
async function getWorkSchedule(scheduleId) {
    // 作業予定IDに一致するデータを検索
    const schedule = await workScheduleStore.getById(scheduleId);
    if (!schedule) {
        throw new errors_1.ResourceNotFoundError('作業予定', scheduleId);
    }
    return schedule;
}
/**
 * 作業予定を作成
 *
 * @param userId ユーザーID
 * @param data 作業予定作成リクエスト
 * @returns 作成された作業予定
 */
async function createWorkSchedule(userId, data) {
    // 盆栽の存在確認
    await bonsaiService.getBonsai(userId, data.bonsaiId);
    // 新しい作業予定データを作成
    const newSchedule = await workScheduleStore.create({
        bonsaiId: data.bonsaiId,
        workType: data.workType,
        scheduledDate: data.scheduledDate,
        description: data.description,
        completed: false // 初期値はfalse
    });
    return newSchedule;
}
/**
 * 作業予定を更新
 *
 * @param scheduleId 作業予定ID
 * @param data 作業予定更新リクエスト
 * @returns 更新された作業予定
 */
async function updateWorkSchedule(scheduleId, data) {
    // 作業予定が存在するか確認
    await getWorkSchedule(scheduleId);
    // 更新データを作成
    const updatedSchedule = await workScheduleStore.update(scheduleId, {
        workType: data.workType,
        scheduledDate: data.scheduledDate,
        description: data.description,
        completed: data.completed
    });
    return updatedSchedule;
}
/**
 * 作業予定を削除
 *
 * @param scheduleId 作業予定ID
 */
async function deleteWorkSchedule(scheduleId) {
    // 作業予定が存在するか確認
    await getWorkSchedule(scheduleId);
    // データストアから削除
    await workScheduleStore.delete(scheduleId);
}
//# sourceMappingURL=workScheduleService.js.map