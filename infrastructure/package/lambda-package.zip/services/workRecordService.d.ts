/**
 * 作業記録サービス
 *
 * このファイルは作業記録データの操作に関するビジネスロジックを提供します。
 */
import { WorkRecord, WorkRecordListResponse, CreateWorkRecordRequest, UpdateWorkRecordRequest } from '../models/workRecord';
/**
 * 作業記録一覧を取得
 *
 * @param userId ユーザーID
 * @param bonsaiId 盆栽ID
 * @param workType 作業タイプでフィルタリング（オプション）
 * @param limit 取得件数（オプション）
 * @param nextToken ページネーショントークン（オプション）
 * @returns 作業記録一覧レスポンス
 */
export declare function listWorkRecords(userId: string, bonsaiId: string, workType?: string, limit?: number, nextToken?: string): Promise<WorkRecordListResponse>;
/**
 * 作業記録詳細を取得
 *
 * @param recordId 作業記録ID
 * @returns 作業記録詳細
 */
export declare function getWorkRecord(recordId: string): Promise<WorkRecord>;
/**
 * 作業記録を作成
 *
 * @param userId ユーザーID
 * @param data 作業記録作成リクエスト
 * @returns 作成された作業記録
 */
export declare function createWorkRecord(userId: string, data: CreateWorkRecordRequest): Promise<WorkRecord>;
/**
 * 作業記録を更新
 *
 * @param recordId 作業記録ID
 * @param data 作業記録更新リクエスト
 * @returns 更新された作業記録
 */
export declare function updateWorkRecord(recordId: string, data: UpdateWorkRecordRequest): Promise<WorkRecord>;
/**
 * 作業記録を削除
 *
 * @param recordId 作業記録ID
 */
export declare function deleteWorkRecord(recordId: string): Promise<void>;
