"use strict";
/**
 * Bonsai App Server
 *
 * このファイルはExpress.jsを使用したサーバーアプリケーションのエントリーポイントです。
 * ローカル開発環境で使用します。
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const body_parser_1 = __importDefault(require("body-parser"));
const index_1 = require("./index");
const response_1 = require("./utils/response");
// Expressアプリケーションを作成
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3000;
// ミドルウェアの設定
app.use((0, cors_1.default)());
app.use(body_parser_1.default.json());
// ヘルスチェックエンドポイント
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString()
    });
});
// Lambda関数をExpressルートとして統合するためのヘルパー関数
const lambdaToExpress = (path, method) => {
    return async (req, res) => {
        try {
            // ExpressリクエストをAPI Gateway形式に変換
            const event = {
                path,
                httpMethod: method,
                headers: req.headers,
                queryStringParameters: req.query,
                pathParameters: req.params,
                body: req.body ? JSON.stringify(req.body) : null
            };
            // Lambda関数を呼び出し
            const result = await (0, index_1.handler)(event);
            // レスポンスを返す
            res.status(result.statusCode).json(JSON.parse(result.body));
        }
        catch (error) {
            console.error('ルートハンドラーエラー:', error);
            const errorResponse = (0, response_1.createErrorResponse)(error);
            res.status(errorResponse.statusCode).json(JSON.parse(errorResponse.body));
        }
    };
};
// 盆栽関連のルート
app.get('/api/bonsai', lambdaToExpress('/api/bonsai', 'GET'));
app.post('/api/bonsai', lambdaToExpress('/api/bonsai', 'POST'));
app.get('/api/bonsai/:bonsaiId', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}`;
    lambdaToExpress(path, 'GET')(req, res);
});
app.put('/api/bonsai/:bonsaiId', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}`;
    lambdaToExpress(path, 'PUT')(req, res);
});
app.delete('/api/bonsai/:bonsaiId', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}`;
    lambdaToExpress(path, 'DELETE')(req, res);
});
// 作業記録関連のルート
app.get('/api/bonsai/:bonsaiId/records', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}/records`;
    lambdaToExpress(path, 'GET')(req, res);
});
app.post('/api/bonsai/:bonsaiId/records', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}/records`;
    lambdaToExpress(path, 'POST')(req, res);
});
app.get('/api/records/:recordId', (req, res) => {
    const path = `/api/records/${req.params.recordId}`;
    lambdaToExpress(path, 'GET')(req, res);
});
app.put('/api/records/:recordId', (req, res) => {
    const path = `/api/records/${req.params.recordId}`;
    lambdaToExpress(path, 'PUT')(req, res);
});
app.delete('/api/records/:recordId', (req, res) => {
    const path = `/api/records/${req.params.recordId}`;
    lambdaToExpress(path, 'DELETE')(req, res);
});
// 作業予定関連のルート
app.get('/api/bonsai/:bonsaiId/schedules', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}/schedules`;
    lambdaToExpress(path, 'GET')(req, res);
});
app.post('/api/bonsai/:bonsaiId/schedules', (req, res) => {
    const path = `/api/bonsai/${req.params.bonsaiId}/schedules`;
    lambdaToExpress(path, 'POST')(req, res);
});
app.get('/api/schedules/:scheduleId', (req, res) => {
    const path = `/api/schedules/${req.params.scheduleId}`;
    lambdaToExpress(path, 'GET')(req, res);
});
app.put('/api/schedules/:scheduleId', (req, res) => {
    const path = `/api/schedules/${req.params.scheduleId}`;
    lambdaToExpress(path, 'PUT')(req, res);
});
app.delete('/api/schedules/:scheduleId', (req, res) => {
    const path = `/api/schedules/${req.params.scheduleId}`;
    lambdaToExpress(path, 'DELETE')(req, res);
});
// 画像アップロード関連のルート
app.post('/api/images/presigned-url', lambdaToExpress('/api/images/presigned-url', 'POST'));
// 認証関連のルート
app.post('/api/auth/login', (req, res) => {
    // 簡易的な認証処理
    const { email, password } = req.body;
    // 開発用の簡易認証
    if (email && password) {
        res.json({
            user: {
                id: 'user123',
                email,
                name: 'テストユーザー',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            tokens: {
                idToken: 'mock-id-token',
                accessToken: 'mock-access-token',
                refreshToken: 'mock-refresh-token'
            }
        });
    }
    else {
        res.status(401).json({
            message: '認証に失敗しました。メールアドレスとパスワードを確認してください。'
        });
    }
});
// プロファイル取得エンドポイント
app.get('/api/profile', (req, res) => {
    // 認証トークンの検証（実際の実装ではJWTを検証）
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        // 開発用の簡易プロファイル
        res.json({
            id: 'user123',
            email: 'user@example.com',
            name: 'テストユーザー',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
    }
    else {
        res.status(401).json({
            message: '認証が必要です。'
        });
    }
});
// エラーハンドリングミドルウェア
app.use((err, req, res, next) => {
    console.error('サーバーエラー:', err);
    res.status(500).json({
        message: 'サーバーエラーが発生しました。',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});
// 404ハンドラー
app.use((req, res) => {
    res.status(404).json({
        message: 'リクエストされたリソースが見つかりません。'
    });
});
// サーバー起動
app.listen(PORT, () => {
    console.log(`サーバーが起動しました: http://localhost:${PORT}`);
    console.log('開発モードで実行中...');
});
exports.default = app;
//# sourceMappingURL=server.js.map