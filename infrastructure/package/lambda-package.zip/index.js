"use strict";
/**
 * Bonsai App Server
 *
 * このファイルはアプリケーションのエントリーポイントです。
 * AWS Lambda関数のハンドラーとして機能します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const response_1 = require("./utils/response");
const bonsaiHandler_1 = require("./handlers/bonsaiHandler");
const imageHandler_1 = require("./handlers/imageHandler");
const workRecordHandler_1 = require("./handlers/workRecordHandler");
const workScheduleHandler_1 = require("./handlers/workScheduleHandler");
/**
 * Lambda関数のハンドラー
 * API Gatewayからのリクエストを処理します
 */
const handler = async (event) => {
    try {
        // リクエストのパスとメソッドを取得（Lambda Function URLとAPI Gateway両方に対応）
        let path = event.path;
        let method = event.httpMethod;
        // Lambda Function URLの場合
        if (event.rawPath) {
            path = event.rawPath;
            console.log('Lambda Function URL rawPath:', path);
        }
        // Lambda Function URLの場合
        if (event.requestContext && event.requestContext.http && event.requestContext.http.method) {
            method = event.requestContext.http.method;
            console.log('Lambda Function URL method:', method);
        }
        // クエリパラメータの処理
        if (!event.queryStringParameters && event.rawQueryString) {
            const rawQueryString = event.rawQueryString;
            console.log('Lambda Function URL rawQueryString:', rawQueryString);
            // クエリパラメータをパース
            const queryParams = {};
            if (rawQueryString) {
                rawQueryString.split('&').forEach((param) => {
                    const [key, value] = param.split('=');
                    if (key && value) {
                        queryParams[key] = decodeURIComponent(value);
                    }
                });
            }
            // イベントオブジェクトにクエリパラメータを設定
            event.queryStringParameters = queryParams;
        }
        console.log(`リクエスト: ${method} ${path}`);
        // ヘルスチェックエンドポイント（認証不要）
        if (path === '/api/health' && method === 'GET') {
            return (0, response_1.createSuccessResponse)({
                status: 'healthy',
                timestamp: new Date().toISOString()
            });
        }
        // 盆栽関連のエンドポイント
        if (path === '/api/bonsai') {
            if (method === 'GET') {
                return await (0, bonsaiHandler_1.getBonsaiList)(event);
            }
            else if (method === 'POST') {
                return await (0, bonsaiHandler_1.createBonsai)(event);
            }
        }
        // 盆栽詳細のエンドポイント
        const bonsaiDetailMatch = path.match(/^\/api\/bonsai\/([^\/\?]+)/);
        if (bonsaiDetailMatch) {
            const bonsaiId = bonsaiDetailMatch[1];
            console.log('盆栽詳細 bonsaiId:', bonsaiId);
            event.pathParameters = { ...event.pathParameters, bonsaiId };
            if (method === 'GET') {
                return await (0, bonsaiHandler_1.getBonsaiDetail)(event);
            }
            else if (method === 'PUT') {
                return await (0, bonsaiHandler_1.updateBonsai)(event);
            }
            else if (method === 'DELETE') {
                return await (0, bonsaiHandler_1.deleteBonsai)(event);
            }
        }
        // 作業記録一覧のエンドポイント
        const workRecordListMatch = path.match(/^\/api\/bonsai\/([^\/\?]+)\/records/);
        if (workRecordListMatch) {
            const bonsaiId = workRecordListMatch[1];
            console.log('作業記録一覧 bonsaiId:', bonsaiId);
            event.pathParameters = { ...event.pathParameters, bonsaiId };
            if (method === 'GET') {
                return await (0, workRecordHandler_1.getWorkRecordList)(event);
            }
            else if (method === 'POST') {
                return await (0, workRecordHandler_1.createWorkRecord)(event);
            }
        }
        // 作業記録詳細のエンドポイント
        const workRecordDetailMatch = path.match(/^\/api\/records\/([^\/\?]+)/);
        if (workRecordDetailMatch) {
            const recordId = workRecordDetailMatch[1];
            console.log('作業記録詳細 recordId:', recordId);
            event.pathParameters = { ...event.pathParameters, recordId };
            if (method === 'GET') {
                return await (0, workRecordHandler_1.getWorkRecordDetail)(event);
            }
            else if (method === 'PUT') {
                return await (0, workRecordHandler_1.updateWorkRecord)(event);
            }
            else if (method === 'DELETE') {
                return await (0, workRecordHandler_1.deleteWorkRecord)(event);
            }
        }
        // 作業予定一覧のエンドポイント
        // クエリパラメータを含まないパスパターンに変更
        const workScheduleListMatch = path.match(/^\/api\/bonsai\/([^\/\?]+)\/schedules/);
        if (workScheduleListMatch) {
            const bonsaiId = workScheduleListMatch[1];
            console.log('作業予定一覧 bonsaiId:', bonsaiId);
            event.pathParameters = { ...event.pathParameters, bonsaiId };
            if (method === 'GET') {
                return await (0, workScheduleHandler_1.getWorkScheduleList)(event);
            }
            else if (method === 'POST') {
                return await (0, workScheduleHandler_1.createWorkSchedule)(event);
            }
        }
        // 作業予定詳細のエンドポイント
        const workScheduleDetailMatch = path.match(/^\/api\/schedules\/([^\/\?]+)/);
        if (workScheduleDetailMatch) {
            const scheduleId = workScheduleDetailMatch[1];
            console.log('作業予定詳細 scheduleId:', scheduleId);
            event.pathParameters = { ...event.pathParameters, scheduleId };
            if (method === 'GET') {
                return await (0, workScheduleHandler_1.getWorkScheduleDetail)(event);
            }
            else if (method === 'PUT') {
                return await (0, workScheduleHandler_1.updateWorkSchedule)(event);
            }
            else if (method === 'DELETE') {
                return await (0, workScheduleHandler_1.deleteWorkSchedule)(event);
            }
        }
        // 画像アップロード用の署名付きURL生成エンドポイント
        if (path === '/api/images/presigned-url' && method === 'POST') {
            return await (0, imageHandler_1.generatePresignedUrl)(event);
        }
        // 未実装のエンドポイント
        return (0, response_1.createSuccessResponse)({
            message: 'Not Found'
        }, 404);
    }
    catch (error) {
        console.error('エラー:', error);
        return (0, response_1.createErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map