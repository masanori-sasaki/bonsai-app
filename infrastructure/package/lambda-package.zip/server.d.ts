/**
 * Bonsai App Server
 *
 * このファイルはExpress.jsを使用したサーバーアプリケーションのエントリーポイントです。
 * ローカル開発環境で使用します。
 */
declare const app: import("express-serve-static-core").Express;
export default app;
