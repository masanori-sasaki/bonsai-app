/**
 * 盆栽ハンドラー
 *
 * このファイルは盆栽関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * 盆栽一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getBonsaiList(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 盆栽詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getBonsaiDetail(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 盆栽を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function createBonsai(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 盆栽を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function updateBonsai(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 盆栽を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function deleteBonsai(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
