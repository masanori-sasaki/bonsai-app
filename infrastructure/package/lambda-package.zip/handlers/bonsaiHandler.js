"use strict";
/**
 * 盆栽ハンドラー
 *
 * このファイルは盆栽関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBonsaiList = getBonsaiList;
exports.getBonsaiDetail = getBonsaiDetail;
exports.createBonsai = createBonsai;
exports.updateBonsai = updateBonsai;
exports.deleteBonsai = deleteBonsai;
const auth_1 = require("../utils/auth");
const errors_1 = require("../utils/errors");
const response_1 = require("../utils/response");
const bonsaiService = __importStar(require("../services/bonsaiService"));
/**
 * 盆栽一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getBonsaiList(event) {
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // クエリパラメータを取得
        const queryParams = event.queryStringParameters || {};
        const limit = queryParams.limit ? parseInt(queryParams.limit, 10) : undefined;
        const nextToken = queryParams.nextToken;
        // 盆栽一覧を取得
        const result = await bonsaiService.listBonsai(userId, limit, nextToken);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(result);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 盆栽詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getBonsaiDetail(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // 盆栽詳細を取得
        const bonsai = await bonsaiService.getBonsai(userId, bonsaiId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(bonsai);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 盆栽を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function createBonsai(event) {
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        // バリデーション
        if (!data.name) {
            throw new errors_1.InvalidRequestError('盆栽名は必須です');
        }
        if (!data.species) {
            throw new errors_1.InvalidRequestError('樹種は必須です');
        }
        if (!data.registrationDate) {
            throw new errors_1.InvalidRequestError('登録日は必須です');
        }
        // 盆栽を作成
        const newBonsai = await bonsaiService.createBonsai(userId, data);
        // 成功レスポンスを返す（201 Created）
        return (0, response_1.createSuccessResponse)(newBonsai, 201);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 盆栽を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function updateBonsai(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        // 盆栽を更新
        const updatedBonsai = await bonsaiService.updateBonsai(userId, bonsaiId, data);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(updatedBonsai);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 盆栽を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function deleteBonsai(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // 盆栽を削除
        await bonsaiService.deleteBonsai(userId, bonsaiId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)({
            message: '盆栽が正常に削除されました',
            id: bonsaiId
        });
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
//# sourceMappingURL=bonsaiHandler.js.map