/**
 * 作業予定ハンドラー
 *
 * このファイルは作業予定関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * 作業予定一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getWorkScheduleList(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業予定詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getWorkScheduleDetail(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業予定を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function createWorkSchedule(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業予定を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function updateWorkSchedule(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業予定を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function deleteWorkSchedule(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
