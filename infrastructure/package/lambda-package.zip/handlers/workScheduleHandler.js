"use strict";
/**
 * 作業予定ハンドラー
 *
 * このファイルは作業予定関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkScheduleList = getWorkScheduleList;
exports.getWorkScheduleDetail = getWorkScheduleDetail;
exports.createWorkSchedule = createWorkSchedule;
exports.updateWorkSchedule = updateWorkSchedule;
exports.deleteWorkSchedule = deleteWorkSchedule;
const auth_1 = require("../utils/auth");
const errors_1 = require("../utils/errors");
const response_1 = require("../utils/response");
const workScheduleService = __importStar(require("../services/workScheduleService"));
/**
 * 作業予定一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getWorkScheduleList(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // クエリパラメータを取得
        const queryParams = event.queryStringParameters || {};
        const completed = queryParams.completed !== undefined ? queryParams.completed === 'true' : undefined;
        const limit = queryParams.limit ? parseInt(queryParams.limit, 10) : undefined;
        const nextToken = queryParams.nextToken;
        // 作業予定一覧を取得
        const result = await workScheduleService.listWorkSchedules(userId, bonsaiId, completed, limit, nextToken);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(result);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業予定詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getWorkScheduleDetail(event) {
    var _a;
    try {
        // パスパラメータから作業予定IDを取得
        const scheduleId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.scheduleId;
        if (!scheduleId) {
            throw new errors_1.InvalidRequestError('作業予定IDが指定されていません');
        }
        // 作業予定詳細を取得
        const schedule = await workScheduleService.getWorkSchedule(scheduleId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(schedule);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業予定を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function createWorkSchedule(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        data.bonsaiId = bonsaiId; // パスパラメータの盆栽IDを設定
        // バリデーション
        if (!data.workType) {
            throw new errors_1.InvalidRequestError('作業タイプは必須です');
        }
        if (!data.scheduledDate) {
            throw new errors_1.InvalidRequestError('予定日は必須です');
        }
        if (!data.description) {
            throw new errors_1.InvalidRequestError('作業内容は必須です');
        }
        // 作業予定を作成
        const newSchedule = await workScheduleService.createWorkSchedule(userId, data);
        // 成功レスポンスを返す（201 Created）
        return (0, response_1.createSuccessResponse)(newSchedule, 201);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業予定を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function updateWorkSchedule(event) {
    var _a;
    try {
        // パスパラメータから作業予定IDを取得
        const scheduleId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.scheduleId;
        if (!scheduleId) {
            throw new errors_1.InvalidRequestError('作業予定IDが指定されていません');
        }
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        // 作業予定を更新
        const updatedSchedule = await workScheduleService.updateWorkSchedule(scheduleId, data);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(updatedSchedule);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業予定を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function deleteWorkSchedule(event) {
    var _a;
    try {
        // パスパラメータから作業予定IDを取得
        const scheduleId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.scheduleId;
        if (!scheduleId) {
            throw new errors_1.InvalidRequestError('作業予定IDが指定されていません');
        }
        // 作業予定を削除
        await workScheduleService.deleteWorkSchedule(scheduleId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)({
            message: '作業予定が正常に削除されました',
            id: scheduleId
        });
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
//# sourceMappingURL=workScheduleHandler.js.map