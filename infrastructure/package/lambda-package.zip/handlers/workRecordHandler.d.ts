/**
 * 作業記録ハンドラー
 *
 * このファイルは作業記録関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * 作業記録一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getWorkRecordList(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業記録詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function getWorkRecordDetail(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業記録を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function createWorkRecord(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業記録を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function updateWorkRecord(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * 作業記録を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function deleteWorkRecord(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
