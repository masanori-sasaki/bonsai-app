"use strict";
/**
 * 作業記録ハンドラー
 *
 * このファイルは作業記録関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkRecordList = getWorkRecordList;
exports.getWorkRecordDetail = getWorkRecordDetail;
exports.createWorkRecord = createWorkRecord;
exports.updateWorkRecord = updateWorkRecord;
exports.deleteWorkRecord = deleteWorkRecord;
const auth_1 = require("../utils/auth");
const errors_1 = require("../utils/errors");
const response_1 = require("../utils/response");
const workRecordService = __importStar(require("../services/workRecordService"));
/**
 * 作業記録一覧を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getWorkRecordList(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // クエリパラメータを取得
        const queryParams = event.queryStringParameters || {};
        const workType = queryParams.workType;
        const limit = queryParams.limit ? parseInt(queryParams.limit, 10) : undefined;
        const nextToken = queryParams.nextToken;
        // 作業記録一覧を取得
        const result = await workRecordService.listWorkRecords(userId, bonsaiId, workType, limit, nextToken);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(result);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業記録詳細を取得
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function getWorkRecordDetail(event) {
    var _a;
    try {
        // パスパラメータから作業記録IDを取得
        const recordId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.recordId;
        if (!recordId) {
            throw new errors_1.InvalidRequestError('作業記録IDが指定されていません');
        }
        // 作業記録詳細を取得
        const record = await workRecordService.getWorkRecord(recordId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(record);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業記録を作成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function createWorkRecord(event) {
    var _a;
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // パスパラメータから盆栽IDを取得
        const bonsaiId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.bonsaiId;
        if (!bonsaiId) {
            throw new errors_1.InvalidRequestError('盆栽IDが指定されていません');
        }
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        data.bonsaiId = bonsaiId; // パスパラメータの盆栽IDを設定
        // バリデーション
        if (!data.workType) {
            throw new errors_1.InvalidRequestError('作業タイプは必須です');
        }
        if (!data.date) {
            throw new errors_1.InvalidRequestError('作業日は必須です');
        }
        if (!data.description) {
            throw new errors_1.InvalidRequestError('作業内容は必須です');
        }
        // 作業記録を作成
        const newRecord = await workRecordService.createWorkRecord(userId, data);
        // 成功レスポンスを返す（201 Created）
        return (0, response_1.createSuccessResponse)(newRecord, 201);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業記録を更新
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function updateWorkRecord(event) {
    var _a;
    try {
        // パスパラメータから作業記録IDを取得
        const recordId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.recordId;
        if (!recordId) {
            throw new errors_1.InvalidRequestError('作業記録IDが指定されていません');
        }
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        // 作業記録を更新
        const updatedRecord = await workRecordService.updateWorkRecord(recordId, data);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)(updatedRecord);
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
/**
 * 作業記録を削除
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function deleteWorkRecord(event) {
    var _a;
    try {
        // パスパラメータから作業記録IDを取得
        const recordId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.recordId;
        if (!recordId) {
            throw new errors_1.InvalidRequestError('作業記録IDが指定されていません');
        }
        // 作業記録を削除
        await workRecordService.deleteWorkRecord(recordId);
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)({
            message: '作業記録が正常に削除されました',
            id: recordId
        });
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
//# sourceMappingURL=workRecordHandler.js.map