/**
 * 画像ハンドラー
 *
 * このファイルは画像関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * 画像アップロード用の署名付きURLを生成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
export declare function generatePresignedUrl(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
