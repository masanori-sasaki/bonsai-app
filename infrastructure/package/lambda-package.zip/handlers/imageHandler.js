"use strict";
/**
 * 画像ハンドラー
 *
 * このファイルは画像関連のAPIリクエストを処理するハンドラー関数を提供します。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatePresignedUrl = generatePresignedUrl;
const aws_sdk_1 = require("aws-sdk");
const uuid_1 = require("uuid");
const auth_1 = require("../utils/auth");
const errors_1 = require("../utils/errors");
const response_1 = require("../utils/response");
// S3クライアントの初期化
const s3 = new aws_sdk_1.S3();
const BUCKET_NAME = process.env.FRONTEND_BUCKET_NAME || 'bonsai-app-dev';
const IMAGE_FOLDER = 'images';
/**
 * 画像アップロード用の署名付きURLを生成
 *
 * @param event APIGatewayProxyEvent
 * @returns APIGatewayProxyResult
 */
async function generatePresignedUrl(event) {
    try {
        // ユーザーIDを取得
        const userId = (0, auth_1.getUserIdFromRequest)(event);
        // リクエストボディをパース
        if (!event.body) {
            throw new errors_1.InvalidRequestError('リクエストボディが空です');
        }
        const data = JSON.parse(event.body);
        // バリデーション
        if (!data.fileName) {
            throw new errors_1.InvalidRequestError('ファイル名は必須です');
        }
        if (!data.fileType) {
            throw new errors_1.InvalidRequestError('ファイルタイプは必須です');
        }
        // サポートする画像形式のみ許可
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!allowedTypes.includes(data.fileType)) {
            throw new errors_1.InvalidRequestError('サポートされていない画像形式です。JPG、PNG、GIF形式のみアップロードできます。');
        }
        // ファイル名を安全に処理（拡張子を維持）
        const fileExt = data.fileName.split('.').pop();
        const safeFileName = `${(0, uuid_1.v4)()}.${fileExt}`;
        // S3のキーを生成（ユーザーIDごとにフォルダ分け）
        const key = `${IMAGE_FOLDER}/${userId}/${safeFileName}`;
        // 署名付きURLを生成（有効期限5分）
        const presignedUrl = s3.getSignedUrl('putObject', {
            Bucket: BUCKET_NAME,
            Key: key,
            ContentType: data.fileType,
            Expires: 300 // 5分
        });
        // 公開URLを生成
        const publicUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;
        // 成功レスポンスを返す
        return (0, response_1.createSuccessResponse)({
            url: presignedUrl,
            publicUrl: publicUrl
        });
    }
    catch (error) {
        // エラーレスポンスを返す
        return (0, response_1.createErrorResponse)(error);
    }
}
//# sourceMappingURL=imageHandler.js.map