/**
 * データストアインターフェース
 *
 * このファイルはデータの永続化を担当するインターフェースと実装を提供します。
 * ローカル環境ではJSONファイルを使用し、開発環境と本番環境ではDynamoDBを使用します。
 */
export interface DataStore<T> {
    getAll(): Promise<T[]>;
    getById(id: string): Promise<T | null>;
    create(item: Omit<T, 'id' | 'createdAt' | 'updatedAt'> & {
        id?: string;
    }): Promise<T>;
    update(id: string, item: Partial<T>): Promise<T>;
    delete(id: string): Promise<void>;
    query(filterFn: (item: T) => boolean): Promise<T[]>;
}
export declare class JsonFileDataStore<T extends {
    id: string;
}> implements DataStore<T> {
    private filePath;
    private data;
    private initialized;
    constructor(entityName: string);
    private initialize;
    private saveData;
    getAll(): Promise<T[]>;
    getById(id: string): Promise<T | null>;
    create(item: Omit<T, 'id' | 'createdAt' | 'updatedAt'> & {
        id?: string;
    }): Promise<T>;
    update(id: string, item: Partial<T>): Promise<T>;
    delete(id: string): Promise<void>;
    query(filterFn: (item: T) => boolean): Promise<T[]>;
}
export declare class DynamoDbDataStore<T extends {
    id: string;
}> implements DataStore<T> {
    private entityName;
    constructor(entityName: string);
    getAll(): Promise<T[]>;
    getById(id: string): Promise<T | null>;
    create(item: Omit<T, 'id' | 'createdAt' | 'updatedAt'> & {
        id?: string;
    }): Promise<T>;
    update(id: string, item: Partial<T>): Promise<T>;
    delete(id: string): Promise<void>;
    query(filterFn: (item: T) => boolean): Promise<T[]>;
    private fromDynamoItem;
    private toDynamoItem;
}
export declare function createDataStore<T extends {
    id: string;
}>(entityName: string): DataStore<T>;
