"use strict";
/**
 * データストアインターフェース
 *
 * このファイルはデータの永続化を担当するインターフェースと実装を提供します。
 * ローカル環境ではJSONファイルを使用し、開発環境と本番環境ではDynamoDBを使用します。
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDbDataStore = exports.JsonFileDataStore = void 0;
exports.createDataStore = createDataStore;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const uuid_1 = require("uuid");
const aws_sdk_1 = __importDefault(require("aws-sdk"));
// 環境設定
// 明示的にfalseが設定されている場合はfalse、それ以外はデフォルトでtrue
const IS_LOCAL = process.env.IS_LOCAL !== 'false' && !process.env.AWS_LAMBDA_FUNCTION_NAME;
// デバッグ用
console.log('環境変数の状態:', {
    IS_LOCAL_ENV: process.env.IS_LOCAL,
    AWS_LAMBDA_FUNCTION_NAME: process.env.AWS_LAMBDA_FUNCTION_NAME,
    IS_LOCAL: IS_LOCAL
});
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
// DynamoDBの設定
const REGION = process.env.AWS_REGION || 'ap-northeast-1';
const ENVIRONMENT = IS_PRODUCTION ? 'prod' : 'dev';
const ACCOUNT_ID = process.env.AWS_ACCOUNT_ID || 'local';
// 環境変数からテーブル名を取得するか、デフォルト値を使用
const TABLE_NAME = process.env.TABLE_NAME || `BonsaiTable-${ENVIRONMENT}-${ACCOUNT_ID}`;
// データディレクトリのパス（JSONファイルストア用）
const DATA_DIR = IS_PRODUCTION
    ? '/tmp/data' // Lambda環境では/tmpディレクトリを使用
    : path_1.default.join(__dirname, '../../data');
// DynamoDBクライアントの設定
const dynamoDbConfig = {
    region: REGION
};
// DynamoDBクライアントの初期化
const dynamoDb = new aws_sdk_1.default.DynamoDB.DocumentClient(dynamoDbConfig);
// JSONファイルベースのデータストア実装
class JsonFileDataStore {
    constructor(entityName) {
        // データディレクトリが存在しない場合は作成
        // try {
        //   if (!fs.existsSync(DATA_DIR)) {
        //     fs.mkdirSync(DATA_DIR, { recursive: true });
        //   }
        // } catch (error) {
        //   console.error(`データディレクトリの作成に失敗しました: ${error}`);
        //   // エラーをスローせず、続行を試みる
        // }
        this.data = [];
        this.initialized = false;
        this.filePath = path_1.default.join(DATA_DIR, `${entityName}.json`);
    }
    // データの初期化
    async initialize() {
        if (this.initialized)
            return;
        try {
            if (fs_1.default.existsSync(this.filePath)) {
                const fileContent = await fs_1.default.promises.readFile(this.filePath, 'utf-8');
                this.data = JSON.parse(fileContent);
            }
            else {
                this.data = [];
                await this.saveData();
            }
            this.initialized = true;
        }
        catch (error) {
            console.error('データ初期化エラー:', error);
            // エラーが発生した場合は空の配列を使用
            this.data = [];
            this.initialized = true;
        }
    }
    // データの保存
    async saveData() {
        try {
            await fs_1.default.promises.writeFile(this.filePath, JSON.stringify(this.data, null, 2), 'utf-8');
        }
        catch (error) {
            console.error(`データの保存に失敗しました: ${error}`);
            // エラーをスローせず、続行を試みる
        }
    }
    // 全アイテムの取得
    async getAll() {
        await this.initialize();
        return [...this.data];
    }
    // IDによるアイテムの取得
    async getById(id) {
        await this.initialize();
        const item = this.data.find(item => item.id === id);
        return item || null;
    }
    // アイテムの作成
    async create(item) {
        await this.initialize();
        const now = new Date().toISOString();
        const newItem = {
            ...item,
            id: item.id || (0, uuid_1.v4)(),
            createdAt: now,
            updatedAt: now
        };
        this.data.push(newItem);
        await this.saveData();
        return newItem;
    }
    // アイテムの更新
    async update(id, item) {
        await this.initialize();
        const index = this.data.findIndex(i => i.id === id);
        if (index === -1) {
            throw new Error(`ID ${id} のアイテムが見つかりません`);
        }
        const updatedItem = {
            ...this.data[index],
            ...item,
            updatedAt: new Date().toISOString()
        };
        this.data[index] = updatedItem;
        await this.saveData();
        return updatedItem;
    }
    // アイテムの削除
    async delete(id) {
        await this.initialize();
        const index = this.data.findIndex(i => i.id === id);
        if (index === -1) {
            throw new Error(`ID ${id} のアイテムが見つかりません`);
        }
        this.data.splice(index, 1);
        await this.saveData();
    }
    // クエリによるアイテムの検索
    async query(filterFn) {
        await this.initialize();
        return this.data.filter(filterFn);
    }
}
exports.JsonFileDataStore = JsonFileDataStore;
// DynamoDB用のデータストア実装
class DynamoDbDataStore {
    constructor(entityName) {
        this.entityName = entityName;
    }
    // 全アイテムの取得
    async getAll() {
        const params = {
            TableName: TABLE_NAME,
            KeyConditionExpression: 'PK = :pk',
            ExpressionAttributeValues: {
                ':pk': `${this.entityName.toUpperCase()}`
            }
        };
        try {
            const result = await dynamoDb.query(params).promise();
            return (result.Items || []).map(item => this.fromDynamoItem(item));
        }
        catch (error) {
            console.error(`DynamoDB getAll エラー:`, error);
            throw error;
        }
    }
    // IDによるアイテムの取得
    async getById(id) {
        const params = {
            TableName: TABLE_NAME,
            Key: {
                PK: `${this.entityName.toUpperCase()}`,
                SK: id
            }
        };
        try {
            const result = await dynamoDb.get(params).promise();
            return result.Item ? this.fromDynamoItem(result.Item) : null;
        }
        catch (error) {
            console.error(`DynamoDB getById エラー:`, error);
            throw error;
        }
    }
    // アイテムの作成
    async create(item) {
        const now = new Date().toISOString();
        const id = item.id || (0, uuid_1.v4)();
        const newItem = {
            ...item,
            id,
            createdAt: now,
            updatedAt: now
        };
        const dynamoItem = this.toDynamoItem(newItem);
        const params = {
            TableName: TABLE_NAME,
            Item: dynamoItem
        };
        try {
            await dynamoDb.put(params).promise();
            return newItem;
        }
        catch (error) {
            console.error(`DynamoDB create エラー:`, error);
            throw error;
        }
    }
    // アイテムの更新
    async update(id, item) {
        // 現在のアイテムを取得
        const currentItem = await this.getById(id);
        if (!currentItem) {
            throw new Error(`ID ${id} のアイテムが見つかりません`);
        }
        const updatedItem = {
            ...currentItem,
            ...item,
            updatedAt: new Date().toISOString()
        };
        const dynamoItem = this.toDynamoItem(updatedItem);
        const params = {
            TableName: TABLE_NAME,
            Item: dynamoItem
        };
        try {
            await dynamoDb.put(params).promise();
            return updatedItem;
        }
        catch (error) {
            console.error(`DynamoDB update エラー:`, error);
            throw error;
        }
    }
    // アイテムの削除
    async delete(id) {
        const params = {
            TableName: TABLE_NAME,
            Key: {
                PK: `${this.entityName.toUpperCase()}`,
                SK: id
            }
        };
        try {
            await dynamoDb.delete(params).promise();
        }
        catch (error) {
            console.error(`DynamoDB delete エラー:`, error);
            throw error;
        }
    }
    // クエリによるアイテムの検索
    async query(filterFn) {
        // DynamoDBでは効率的なフィルタリングが難しいため、全アイテムを取得してからフィルタリング
        const allItems = await this.getAll();
        return allItems.filter(filterFn);
    }
    // DynamoDBアイテムからモデルへの変換
    fromDynamoItem(item) {
        // PK, SK, GSI1PK, GSI1SKを除外し、残りの属性を返す
        const { PK, SK, GSI1PK, GSI1SK, ...data } = item;
        return data;
    }
    // モデルからDynamoDBアイテムへの変換
    toDynamoItem(item) {
        const updatedAt = item.updatedAt || new Date().toISOString();
        return {
            PK: `${this.entityName.toUpperCase()}`,
            SK: item.id,
            GSI1PK: `${this.entityName.toUpperCase()}#${item.id}`,
            GSI1SK: updatedAt,
            ...item
        };
    }
}
exports.DynamoDbDataStore = DynamoDbDataStore;
// データストアのファクトリ関数
function createDataStore(entityName) {
    // ローカル環境ではJSONファイルを使用し、それ以外の環境ではDynamoDBを使用
    if (IS_LOCAL) {
        console.log(`ローカル環境: ${entityName} にJSONファイルストアを使用します`);
        return new JsonFileDataStore(entityName);
    }
    else {
        console.log(`クラウド環境: ${entityName} にDynamoDBストアを使用します`);
        return new DynamoDbDataStore(entityName);
    }
}
//# sourceMappingURL=dataStore.js.map