"use strict";
/**
 * データストアインターフェース
 *
 * このファイルはデータの永続化を担当するインターフェースと実装を提供します。
 * 開発環境ではJSONファイルを使用し、本番環境ではDynamoDBを使用する想定です。
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonFileDataStore = void 0;
exports.createDataStore = createDataStore;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const uuid_1 = require("uuid");
// データディレクトリのパス
const DATA_DIR = path_1.default.join(__dirname, '../../data');
// JSONファイルベースのデータストア実装
class JsonFileDataStore {
    constructor(entityName) {
        this.data = [];
        this.initialized = false;
        // データディレクトリが存在しない場合は作成
        if (!fs_1.default.existsSync(DATA_DIR)) {
            fs_1.default.mkdirSync(DATA_DIR, { recursive: true });
        }
        this.filePath = path_1.default.join(DATA_DIR, `${entityName}.json`);
    }
    // データの初期化
    async initialize() {
        if (this.initialized)
            return;
        try {
            if (fs_1.default.existsSync(this.filePath)) {
                const fileContent = await fs_1.default.promises.readFile(this.filePath, 'utf-8');
                this.data = JSON.parse(fileContent);
            }
            else {
                this.data = [];
                await this.saveData();
            }
            this.initialized = true;
        }
        catch (error) {
            console.error('データ初期化エラー:', error);
            this.data = [];
            this.initialized = true;
        }
    }
    // データの保存
    async saveData() {
        await fs_1.default.promises.writeFile(this.filePath, JSON.stringify(this.data, null, 2), 'utf-8');
    }
    // 全アイテムの取得
    async getAll() {
        await this.initialize();
        return [...this.data];
    }
    // IDによるアイテムの取得
    async getById(id) {
        await this.initialize();
        const item = this.data.find(item => item.id === id);
        return item || null;
    }
    // アイテムの作成
    async create(item) {
        await this.initialize();
        const now = new Date().toISOString();
        const newItem = {
            ...item,
            id: item.id || (0, uuid_1.v4)(),
            createdAt: now,
            updatedAt: now
        };
        this.data.push(newItem);
        await this.saveData();
        return newItem;
    }
    // アイテムの更新
    async update(id, item) {
        await this.initialize();
        const index = this.data.findIndex(i => i.id === id);
        if (index === -1) {
            throw new Error(`ID ${id} のアイテムが見つかりません`);
        }
        const updatedItem = {
            ...this.data[index],
            ...item,
            updatedAt: new Date().toISOString()
        };
        this.data[index] = updatedItem;
        await this.saveData();
        return updatedItem;
    }
    // アイテムの削除
    async delete(id) {
        await this.initialize();
        const index = this.data.findIndex(i => i.id === id);
        if (index === -1) {
            throw new Error(`ID ${id} のアイテムが見つかりません`);
        }
        this.data.splice(index, 1);
        await this.saveData();
    }
    // クエリによるアイテムの検索
    async query(filterFn) {
        await this.initialize();
        return this.data.filter(filterFn);
    }
}
exports.JsonFileDataStore = JsonFileDataStore;
// データストアのファクトリ関数
function createDataStore(entityName) {
    return new JsonFileDataStore(entityName);
}
//# sourceMappingURL=dataStore.js.map